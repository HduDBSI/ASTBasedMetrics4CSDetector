    @Override
    public Iterator<LdapComparator<?>> iterator()
    {
        return immutableComparatorRegistry.iterator();
    }