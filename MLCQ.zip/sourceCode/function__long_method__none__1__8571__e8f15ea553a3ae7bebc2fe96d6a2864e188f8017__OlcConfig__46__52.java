    public void addAuxiliaryObjectClasses( AuxiliaryObjectClass... auxiliaryObjectClasses )
    {
        for ( AuxiliaryObjectClass auxiliaryObjectClass : auxiliaryObjectClasses )
        {
            this.auxiliaryObjectClasses.add( auxiliaryObjectClass );
        }
    }