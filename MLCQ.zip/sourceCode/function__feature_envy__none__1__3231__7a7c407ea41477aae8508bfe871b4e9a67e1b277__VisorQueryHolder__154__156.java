    public boolean isAccessed() {
        return accessed;
    }