  @Override
  public IHelpInformation getHelpInformation() {
    return new CPasswordHelp();
  }