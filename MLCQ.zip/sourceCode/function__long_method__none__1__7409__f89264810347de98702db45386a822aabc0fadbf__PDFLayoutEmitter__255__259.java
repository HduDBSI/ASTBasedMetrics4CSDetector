	public void endContainer( IContainerContent container )
			throws BirtException
	{
		_endContainer( container );
	}