public abstract class AbstractRunnable implements ICallable<Void> {
  public final Void call(IMavenExecutionContext context, IProgressMonitor monitor) throws CoreException {
    run(context, monitor);
    return null;
  }

  protected abstract void run(IMavenExecutionContext context, IProgressMonitor monitor) throws CoreException;
}