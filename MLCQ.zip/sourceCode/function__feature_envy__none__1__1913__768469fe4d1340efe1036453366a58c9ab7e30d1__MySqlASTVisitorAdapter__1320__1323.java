    @Override
    public boolean visit(MySqlShowDatabasePartitionStatusStatement x) {
        return true;
    }