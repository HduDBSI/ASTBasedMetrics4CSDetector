    public StateMachine() {
        _initialStateEntry = new StateEntry(null);
    }