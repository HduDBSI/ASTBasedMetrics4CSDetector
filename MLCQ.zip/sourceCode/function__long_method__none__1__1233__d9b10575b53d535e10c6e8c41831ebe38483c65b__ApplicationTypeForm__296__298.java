    private void appTypeUrlFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_appTypeUrlFocusLost
        appTypeUrl.setSelectionEnd(0);
    }//GEN-LAST:event_appTypeUrlFocusLost