	public boolean isMinExclusive() {
		return minExclusive;
	}