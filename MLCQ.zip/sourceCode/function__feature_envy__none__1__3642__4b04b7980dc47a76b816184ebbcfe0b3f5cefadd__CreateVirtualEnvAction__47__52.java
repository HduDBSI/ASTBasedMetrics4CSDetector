    public CreateVirtualEnvAction(Project project, PythonDetails pythonDetails,
                                  EditablePythonAbiContainer editablePythonAbiContainer) {
        this.project = project;
        this.pythonDetails = pythonDetails;
        this.editablePythonAbiContainer = editablePythonAbiContainer;
    }