    public static class ruleDoubleLiteral_return extends ParserRuleReturnScope {
    };