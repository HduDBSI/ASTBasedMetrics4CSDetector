        public RBuiltinNode getBuiltin() {
            return builtin;
        }