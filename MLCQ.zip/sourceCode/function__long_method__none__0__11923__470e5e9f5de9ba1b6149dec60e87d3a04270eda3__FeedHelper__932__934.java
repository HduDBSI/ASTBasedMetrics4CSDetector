    public static Date getImportInitalInstance(org.apache.falcon.entity.v0.feed.Cluster feedCluster) {
        return feedCluster.getValidity().getStart();
    }