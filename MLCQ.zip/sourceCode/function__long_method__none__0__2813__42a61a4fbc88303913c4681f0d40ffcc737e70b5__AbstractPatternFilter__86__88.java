  void setIncludePattern(Pattern includePattern) {
    this.includePattern = includePattern;
  }