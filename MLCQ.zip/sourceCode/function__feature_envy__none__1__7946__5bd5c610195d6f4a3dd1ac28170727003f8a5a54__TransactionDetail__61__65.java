   public TransactionDetail(Xid xid, Transaction tx, Long creation) {
      this.xid = xid;
      this.transaction = tx;
      this.creationTime = creation;
   }