    @Override
    public String toString()
    {
        return "(" + left + "," + right + ")";
    }