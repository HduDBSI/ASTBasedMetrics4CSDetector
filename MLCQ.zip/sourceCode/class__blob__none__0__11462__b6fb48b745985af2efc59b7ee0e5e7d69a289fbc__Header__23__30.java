public class Header {
    @SerializedName("typ")
    public String type;
    @SerializedName("alg")
    public String algorithm;
    @SerializedName("cty")
    public String contentType;
}