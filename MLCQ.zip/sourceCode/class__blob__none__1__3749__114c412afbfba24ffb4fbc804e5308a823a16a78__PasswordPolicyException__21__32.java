public class PasswordPolicyException extends PolicyException {

    private static final long serialVersionUID = 8072104484395278469L;

    public PasswordPolicyException() {
        super();
    }

    public PasswordPolicyException(final String message) {
        super(message);
    }
}