        public IDataType getElemType() {
            return elemType;
        }