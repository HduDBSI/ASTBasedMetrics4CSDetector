  private SparkSkewJoinProcFactory() {
    // prevent instantiation
  }