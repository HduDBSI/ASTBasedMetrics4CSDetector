    @Override
    public void dispose()
    {
        this.managers.clear();
    }