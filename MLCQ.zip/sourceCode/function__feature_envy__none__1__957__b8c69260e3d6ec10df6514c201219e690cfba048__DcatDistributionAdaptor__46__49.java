  @Override
  public String getType() {
    return getString("@type");
  }